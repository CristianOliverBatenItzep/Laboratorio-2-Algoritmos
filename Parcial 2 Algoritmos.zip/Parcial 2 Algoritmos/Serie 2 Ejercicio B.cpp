#include <iostream>
using namespace std;

int main() {
    int numero;

    cout << "Ingrese un numero (1: Primavera, 2: Verano, 3: Otonio, 4: Invierno): ";
    cin >> numero;

    switch (numero) {
        case 1:
            cout << "Primavera" << endl;
            break;
        case 2:
            cout << "Verano" << endl;
            break;
        case 3:
            cout << "Oto�o" << endl;
            break;
        case 4:
            cout << "Invierno" << endl;
            break;
        default:
            cout << "Numero no valido. Debe ser un numero entre 1 y 4." << endl;
    }

    return 0;
}

